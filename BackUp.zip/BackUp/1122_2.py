
# coding: utf-8

# #### モジュールのインポート等

# In[3]:


import time
import random
import numpy as np
from PIL import Image
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier,AdaBoostClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.model_selection import train_test_split,GridSearchCV
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm
get_ipython().magic('matplotlib inline')
DEBUG = 1
# JIS X 0201のカタカナのコード
JIS_code={166:'ヲ',167:'ァ',168:'ィ',169:'ゥ',170:'ェ',171:'ォ',172:'ャ',173:'ュ',174:'ョ',175:'ッ',176:'ー',177:'ア',178:'イ',179:'ウ',180:'エ',181:'オ',182:'カ',183:'キ',184:'ク',185:'ケ',186:'コ',187:'サ',188:'シ',189:'ス',190:'セ',191:'ソ',192:'タ',193:'チ',194:'ツ',195:'テ',196:'ト',197:'ナ',198:'ニ',199:'ヌ',200:'ネ',201:'ノ',202:'ハ',203:'ヒ',204:'フ',205:'ヘ',206:'ホ',207:'マ',208:'ミ',209:'ム',210:'メ',211:'モ',212:'ヤ',213:'ユ',214:'ヨ',215:'ラ',216:'リ',217:'ル',218:'レ',219:'ロ',220:'ワ',221:'ン',222:'゛',223:'゜'}


# #### matplotlib で日本語を使用するため、日本語フォントの有無を確認

# In[4]:


font_jp_exsits = True # 日本語フォント有無
font_jp = ('Yu Gothic','Meiryo UI','Hiragino Sans','Osaka','TakaoGothic','VL Gothic','IPAPGothic')
font_family_jp = {'family': font_jp}
for font in fm.findSystemFonts():
    if fm.FontProperties(fname=font).get_name() in font_jp:
        plt.rc('font', **font_family_jp)
        break
else:font_jp_exsits = False


# #### ファイルからデータを抽出

# In[5]:


# データファイル「（常用）手書カタカナ文字データベースＥＴＬ５」の読込
with open("ETL5C", "rb") as file : original_data = file.read()

# レコードに分割
rec_bytes = 2952
records = [original_data[i:i+rec_bytes] for i in range(0, len(original_data), rec_bytes)]

# リサイズ後イメージサイズを指定(元は 72×76)
img_sz_x, img_sz_y = 36, 38

# レコードからデータを抽出
data = np.zeros((len(records), img_sz_x*img_sz_y), dtype=np.int)   #_ shape = (#data, #feature)
target = np.zeros(len(records), dtype=np.int)                      #_ shape = (#data,)

for idx, record in enumerate(records):
    # レコードからカタカナのJISコード(10Byte目) = 目的変数 を抽出
    target[idx] = record[9]
    
    # レコードから画像データ(216Byte以降)を抽出 (x:72px, y:76px, 4bit/px)
    img = Image.frombytes('F', (72, 76), record[216:], 'bit', 4).convert('L')
    img = np.asarray(Image.eval(img, lambda x: 255-x*16))

    # 処理速度を上げるためリサイズ
    img = np.array(Image.fromarray(img).resize((img_sz_x,img_sz_y)))    

    # 画像データはフラット化する
    data[idx] = img.reshape(img.shape[0]*img.shape[1])
    pass


# #### 抽出した画像データを確認

# In[6]:


plt.figure(figsize=(100,10))
n = 0
for i in range(1,10001,1000):
    n += 1
    kana = JIS_code[target[i]]
    plt.subplot(1,10,n)
    if font_jp_exsits:
        plt.title(kana,size=150)
    else:
        print(kana+'   ', end='')
    plt.imshow(data[i].reshape(img_sz_y,img_sz_x))
    pass


# #### 複数モデルで性能を比較

# In[7]:


# データサイズ（データ総数:10608）
data_sizes=[250, 500, 1000, 2000]
print('Classifier            score')
print('-------------------------------------------------------------')

# 主要な分類器（とりあえず、ハイパーパラメータは全てデフォルトとする）
clfs = {'LogisticRegression':LogisticRegression(),
        'KNeighbors':KNeighborsClassifier(),
        'RandomForest':RandomForestClassifier(),
        'GaussianNB':GaussianNB(),
        'DecisionTree':DecisionTreeClassifier(),
        'AdaBoost':AdaBoostClassifier(),
        'NeuralNetwork':MLPClassifier(),
        'SupportVectorMachine':SVC(),}

# 分類器毎にループ
for name, clf in clfs.items():
    start = time.time()
    print('{:22}'.format(name), end='')
    # データサイズでループ
    for i, size in enumerate(data_sizes):
        # トレーニング/テストデータを作成(テストデータは20％とする)
        X_train, X_test, y_train, y_test = train_test_split(data[-size:], target[-size:], test_size=0.2)
        # トレーニングとテスト
        clf.fit(X_train, y_train)
        score = clf.score(X_test, y_test)
        print('{:.2f}{}'.format(score,' -> ' if (i!=len(data_sizes)-1) else ''), end='')
    print('  | {:2.1f}sec'.format(time.time()-start))
print('-------------------------------------------------------------', end='')


# #### RandomForest の速度とスコアが良かったので、グリッドサーチでパラメータを調整

# In[13]:


# データサイズ（データ総数:10608）
data_sizes=[250, 500, 1000, 2000]
print('RandomForest')
print('---------------------------------------------------')
# データサイズでループ
n = 0
for size in data_sizes:
    n += 1
    start = time.time()
    params = {
        'n_estimators'      : [100, 500, 1000],
        'max_features'      : [10, 15],
        'min_samples_split' : [2, 3],
        'max_depth'         : [15, 20]
    }
    # トレーニング/テストデータを作成(テストデータは20％とする)
    X_train, X_test, y_train, y_test =         train_test_split(data[-size:], target[-size:], test_size=0.2, random_state=1)
    # グリッドサーチでトレーニングとテスト
    clf = GridSearchCV(RandomForestClassifier(), params, cv=3)
    clf.fit(X_train, y_train)
    score = clf.score(X_test, y_test)
    print('{}回目 {:.3f}({:.1f}s) '.format(n, score,time.time()-start), end='')
    if DEBUG: print(clf.best_params_)
print('-------------------------------------------------------------', end='')        


# #### RandomForest の調整後パラメータでトレーニングとテスト

# In[22]:


size = 2000
# トレーニング/テストデータを作成(テストデータは20％とする)
X_train, X_test, y_train, y_test = train_test_split(data[-size:], target[-size:], test_size=0.2, random_state=10)
# グリッドサーチでトレーニングとテスト
clf = RandomForestClassifier(n_estimators=1000,max_features=15,min_samples_split=2,max_depth=20)
clf.fit(X_train, y_train)
score = clf.score(X_test, y_test)
print('{:.3f}'.format(score), end='')


# #### 結果を視覚化

# In[23]:


plt.figure(figsize=(100,10))
for i in range(10):
    ans  = JIS_code[y_test[i]]
    pred = JIS_code[clf.predict(X_test[i].reshape(1,X_test[i].shape[0]))[0]]
    result = '○' if ans==pred else '×'
    plt.subplot(1,10,i+1)
    if font_jp_exsits:
        plt.title(' '+pred+result,size=150)
    else:
        print('['+pred+']→'+result+'   ', end='')
    plt.imshow(X_test[i].reshape(img_sz_y,img_sz_x))
    pass

