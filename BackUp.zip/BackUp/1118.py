
# coding: utf-8

# ### １．データファイルからトレーニングデータとテストデータを作成する

# In[36]:


import struct
import random
import numpy as np
import matplotlib.pyplot as plt
import scipy
from PIL import Image
get_ipython().magic('matplotlib inline')

#データファイルの読み込み
with open("ETL5C", "rb") as file:
    original_data = file.read()

#レコードに分割
rec_size = 2952
records = [original_data[i:i+rec_size] for i in range(0, len(original_data), rec_size)]

dataset = []
for record in records:
    #レコードからカタカナのJISコード(10Byte目) = 目的変数 を抽出
    target = record[9]

    #レコードから画像データ(216Byte以降)を抽出 (x:72px, y:76px, 4bit/px)
    img = Image.frombytes('F', (72, 76), record[216:], 'bit', 4)
    img = img.convert('L')
    img = (img,)
    img = Image.eval(img[0], lambda x: 255-x*16)
    img = np.asarray(img)

    #データセットに追加
    dataset.append((target,img))

#データセットをシャッフルする
random.shuffle(dataset)
#トレーニングデータとテストデータに分ける 10608レコード → トレーニング:8000, テスト:2000 
dataset_train = dataset[0:8000]
dataset_test = dataset[8000:10000]
#---- DEBUG -----------
#JIS_X0201_katakana={166:'ヲ',167:'ァ',168:'ィ',169:'ゥ',170:'ェ',171:'ォ',172:'ャ',173:'ュ',174:'ョ',175:'ッ',176:'ー',177:'ア',178:'イ',179:'ウ',180:'エ',181:'オ',182:'カ',183:'キ',184:'ク',185:'ケ',186:'コ',187:'サ',188:'シ',189:'ス',190:'セ',191:'ソ',192:'タ',193:'チ',194:'ツ',195:'テ',196:'ト',197:'ナ',198:'ニ',199:'ヌ',200:'ネ',201:'ノ',202:'ハ',203:'ヒ',204:'フ',205:'ヘ',206:'ホ',207:'マ',208:'ミ',209:'ム',210:'メ',211:'モ',212:'ヤ',213:'ユ',214:'ヨ',215:'ラ',216:'リ',217:'ル',218:'レ',219:'ロ',220:'ワ',221:'ン',222:'゛',223:'゜'}
#print(JIS_X0201_katakana[dataset_test[0][0]])
#plt.imshow(dataset_test[0][1])
#----------------------

