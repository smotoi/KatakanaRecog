
# coding: utf-8

# ### １．データファイルからトレーニングデータとテストデータを作成する

# #### モジュールのインポート等

# In[133]:


import random
import numpy as np
import matplotlib.pyplot as plt
from PIL import Image
from sklearn.linear_model import LogisticRegression
import matplotlib.font_manager as fm
get_ipython().magic('matplotlib inline')
# デバッグ用
DEBUG=1
# JIS X 0201のカタカナのコード
JIS_code={166:'ヲ',167:'ァ',168:'ィ',169:'ゥ',170:'ェ',171:'ォ',172:'ャ',173:'ュ',174:'ョ',175:'ッ',176:'ー',177:'ア',178:'イ',179:'ウ',180:'エ',181:'オ',182:'カ',183:'キ',184:'ク',185:'ケ',186:'コ',187:'サ',188:'シ',189:'ス',190:'セ',191:'ソ',192:'タ',193:'チ',194:'ツ',195:'テ',196:'ト',197:'ナ',198:'ニ',199:'ヌ',200:'ネ',201:'ノ',202:'ハ',203:'ヒ',204:'フ',205:'ヘ',206:'ホ',207:'マ',208:'ミ',209:'ム',210:'メ',211:'モ',212:'ヤ',213:'ユ',214:'ヨ',215:'ラ',216:'リ',217:'ル',218:'レ',219:'ロ',220:'ワ',221:'ン',222:'゛',223:'゜'}


# #### matplotlib で使用する日本語フォントの有無を確認

# In[134]:


font_jp_exsits = True
font_jp = ('Yu Gothic','Meiryo UI','Hiragino Sans','Osaka','TakaoGothic','VL Gothic','IPAPGothic')
font_family_jp = {'family': font_jp}
for font in fm.findSystemFonts():
    if fm.FontProperties(fname=font).get_name() in font_jp:
        plt.rc('font', **font_family_jp)
        break
else:font_jp_exsits = False


# In[135]:


# 圧縮後イメージサイズ　元は 72px×76px
img_sz_x = 36#72#36#18
img_sz_y = 38#76#38#19


# In[136]:


# データファイルの読み込み
with open("ETL5C", "rb") as file:
    original_data = file.read()

# レコードに分割
rec_size = 2952
records = [original_data[i:i+rec_size] for i in range(0, len(original_data), rec_size)]

dataset = []
for record in records:
    # レコードからカタカナのJISコード(10Byte目) = 目的変数 を抽出
    target = record[9]
    # レコードから画像データ(216Byte以降)を抽出 (x:72px, y:76px, 4bit/px)
    img = Image.frombytes('F', (72, 76), record[216:], 'bit', 4)
    img = img.convert('L')
    img = (img,)
    img = Image.eval(img[0], lambda x: 255-x*16)
    img = np.asarray(img)
    # リサイズ
    pil_img = Image.fromarray(img)
    pil_img = pil_img.resize((img_sz_x,img_sz_y))
    img = np.array(pil_img)    
    # データセットに追加
    dataset.append((target,img))
    
# データセットをシャッフル
random.shuffle(dataset)

# トレーニングデータとテストデータに分割(全10608レコード)
m_train = 4000
m_test  = 500
dataset_train = dataset[:m_train]
dataset_test =  dataset[-m_test:]
Y_train = np.array([i[0] for i in dataset_train]) # shape = (#data,)
Y_test  = np.array([i[0] for i in dataset_test])
X_train = np.array([i[1].reshape(i[1].shape[0]*i[1].shape[1]) for i in dataset_train]) # shape = (#data, #feature)
X_test  = np.array([i[1].reshape(i[1].shape[0]*i[1].shape[1]) for i in dataset_test])


# #### 抽出した画像データを確認（デバッグ時）

# In[137]:


if DEBUG:
    plt.figure(figsize=(100,10))
    for i in range(10):
        target = JIS_code[dataset_test[i][0]]
        plt.subplot(1,10,i+1)
        if font_jp_exsits:
            plt.title(target,size=150)
        else:
            print(target+'   ', end='')
        plt.imshow(dataset_test[i][1])


# #### モデルでトレーニング

# In[138]:


clf_LogisticRegression = LogisticRegression()
clf_LogisticRegression.fit(X_train, Y_train)


# #### テストデータでスコアを確認

# In[139]:


clf_LogisticRegression.score(X_test, Y_test)


# #### 結果の一部を視覚化

# In[146]:


# 結果確認
plt.figure(figsize=(100,10))
for i in range(10):
    ans  = JIS_code[Y_test[i]]
    pred = JIS_code[clf_LogisticRegression.predict(X_test[i].reshape(1,X_test[i].shape[0]))[0]]
    result = '○' if ans==pred else '×'
    plt.subplot(1,10,i+1)
    if font_jp_exsits:
        plt.title(' '+pred+result,size=150)
    else:
        print('['+pred+']→'+result+'   ', end='')
    plt.imshow(X_test[i].reshape(img_sz_y,img_sz_x))

